const backendUrl = 'http://localhost:4000';

export default backendUrl;
